#-*-coding:utf-8-*-
# Author:Lu Wei
from datetime import datetime

v1=datetime.now()
print(v1)
v2=datetime.utcnow()
print(v2)